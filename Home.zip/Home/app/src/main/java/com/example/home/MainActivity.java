package com.example.home;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    private volatile Socket socket;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Switch sw1 = (Switch)findViewById(R.id.light);
        sw1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                ImageView img = (ImageView) findViewById(R.id.bulb);
                String str1;
                if (sw1.isChecked()) {
                    str1 = "1";
                    img.setImageResource(R.drawable.turned_on);

                }else {
                    str1 = "0";
                    img.setImageResource(R.drawable.turned_off);

                }
                new send(str1).execute();
            }
        });
        Switch sw2 = (Switch)findViewById(R.id.fan);
        sw2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                ImageView img = (ImageView) findViewById(R.id.fans);
                String str1;
                if (sw2.isChecked()) {
                    str1 = "2";
                    img.setImageResource(R.drawable.fan_on);
                }else{
                    str1 = "3";
                    img.setImageResource(R.drawable.fan_off);
                }

                new send(str1).execute();
            }
        });
    }



    class send extends AsyncTask<String,String,String> {

        String s;
        send(String s){
            this.s =s;
        }
        @Override
        protected String doInBackground(String... p) {
            try {
                socket = new Socket("192.168.1.4", 23);
                DataOutputStream dout = new DataOutputStream(socket.getOutputStream());
                dout.writeBytes(s);dout.writeBytes(s);dout.writeBytes(s);
                dout.flush();
                dout.close();
            }
            catch(IOException e){
                e.printStackTrace();
            }
            return null;
        }
    }
}





